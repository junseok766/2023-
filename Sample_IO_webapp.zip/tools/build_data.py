"""기본부문 투입산출표 엑셀(12개 시트) → data/*.json 변환
사용법: python tools/build_data.py [엑셀이 있는 폴더 또는 xlsx 경로]
필요: pip install openpyxl
"""
import json, re, sys, unicodedata
from pathlib import Path
from openpyxl import load_workbook

arg = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
if arg.is_file():
    src = arg
else:
    cands = [p for p in arg.rglob('*.xlsx') if '기본부문' in unicodedata.normalize('NFC', p.name)]
    if not cands:
        sys.exit('기본부문 xlsx를 찾지 못했습니다.')
    src = cands[0]

out = Path(__file__).resolve().parent.parent / 'data'
out.mkdir(exist_ok=True)

clean = lambda s: re.sub(r'\s+', ' ', str(s)).strip() if s is not None else ''

def num(x):
    if isinstance(x, float):
        if x == int(x) and abs(x) < 1e15:
            return int(x)
        return round(x, 10) if abs(x) < 100 else round(x, 1)
    if isinstance(x, (int, type(None))):
        return x
    return clean(x)

wb = load_workbook(src, read_only=True, data_only=True)
manifest = []
for k, ws in enumerate(wb.worksheets, 1):
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    unit = clean(rows[3][0]) or '계수 (단위 없음)'
    body = [r for r in rows[6:] if r[0] is not None]
    data = {
        'title': clean(rows[0][0]),
        'unit': unit,
        'colCodes': [clean(c) for c in rows[4][2:]],
        'colNames': [clean(c) for c in rows[5][2:]],
        'rowCodes': [clean(r[0]) for r in body],
        'rowNames': [clean(r[1]) for r in body],
        'v': [[num(x) for x in r[2:]] for r in body],
    }
    fn = f's{k:02d}.json'
    (out / fn).write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    manifest.append({'name': ws.title, 'file': fn})
    print(fn, ws.title, len(body), 'x', len(data['colCodes']))

(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False), encoding='utf-8')
print('완료 →', out)
