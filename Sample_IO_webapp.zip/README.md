# 2023 산업연관표 분석 웹앱

한국은행 2023년 산업연관표(연장표) 기본부문(380개 부문) 투입산출표를 이용한 정적 웹앱입니다.
서버 없이 브라우저에서 계산하며 GitHub Pages로 바로 배포할 수 있습니다.

## 기능
1. **원자료 탐색** – 12개 시트의 행을 선택해 각 열 값을 확인 (합계·분석지표 행 포함)
2. **수요충격 시뮬레이터** – 산업별 국내 최종수요 증가액(백만원)을 입력하면 `생산유발계수 · 수입유발계수 · 부가가치유발계수`로 산업별 생산/수입/부가가치 유발액 계산, 전체 380개 부문 CSV 다운로드
3. **계수 검증** – `A = Ad + Am`, `(I − Ad)⁻¹ = 생산유발계수`, 열합 일치 여부를 브라우저에서 재계산

## GitHub Pages 배포
1. 새 저장소를 만들고 이 폴더의 모든 파일(`data/` 포함)을 올립니다.
2. **Settings → Pages → Branch: `main` / `(root)`** 선택 후 Save
3. `https://<계정>.github.io/<저장소>/` 에서 확인

## 로컬 실행
```bash
python -m http.server 8000   # http://localhost:8000
```
(`file://`로 직접 열면 JSON을 불러올 수 없습니다.)

## 데이터 재생성
```bash
pip install openpyxl
python tools/build_data.py <기본부문 xlsx가 있는 폴더>
```

## 구조
```
index.html          # 웹앱 전체 (HTML/CSS/JS, 외부 라이브러리 없음)
data/               # 엑셀 12개 시트를 변환한 JSON (s01~s12, manifest.json)
tools/build_data.py # 엑셀 → JSON 변환 스크립트
```
